import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const { isDarkMode, toggleDarkMode } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white dark:bg-gray-900 shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <ShoppingBag size={32} className="text-[#fc4b08]" />
              <span className="ml-2 text-2xl font-bold text-[#fc4b08]">Pilla Pilla</span>
            </Link>
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? (
                <Sun size={24} className="text-[#fc4b08]" />
              ) : (
                <Moon size={24} className="text-[#fc4b08]" />
              )}
            </button>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex md:items-center md:space-x-4">
            <NavLink to="/" current={location.pathname === "/"}>
              Inicio
            </NavLink>
            <NavLink to="/products" current={location.pathname === "/products"}>
              Productos
            </NavLink>
            <NavLink to="/locations" current={location.pathname === "/locations"}>
              Ubicaciones
            </NavLink>
            <NavLink to="/contact" current={location.pathname === "/contact"}>
              Contacto
            </NavLink>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button 
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-[#fc4b08] hover:text-white hover:bg-[#fc4b08] focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#fc4b08]"
            >
              <span className="sr-only">Open main menu</span>
              <svg
                className={`${isMenuOpen ? 'hidden' : 'block'} h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
              <svg
                className={`${isMenuOpen ? 'block' : 'hidden'} h-6 w-6`}
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={`${isMenuOpen ? 'block' : 'hidden'} md:hidden bg-white dark:bg-gray-900 shadow-lg`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <MobileNavLink to="/" current={location.pathname === "/"} onClick={() => setIsMenuOpen(false)}>
            Inicio
          </MobileNavLink>
          <MobileNavLink to="/products" current={location.pathname === "/products"} onClick={() => setIsMenuOpen(false)}>
            Productos
          </MobileNavLink>
          <MobileNavLink to="/locations" current={location.pathname === "/locations"} onClick={() => setIsMenuOpen(false)}>
            Ubicaciones
          </MobileNavLink>
          <MobileNavLink to="/contact" current={location.pathname === "/contact"} onClick={() => setIsMenuOpen(false)}>
            Contacto
          </MobileNavLink>
        </div>
      </div>
    </nav>
  );
};

interface NavLinkProps {
  to: string;
  current: boolean;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ to, current, children }) => {
  return (
    <Link
      to={to}
      className={`nav-link ${current ? 'nav-link-active' : 'nav-link-inactive'}`}
    >
      {children}
    </Link>
  );
};

interface MobileNavLinkProps extends NavLinkProps {
  onClick: () => void;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, current, onClick, children }) => {
  return (
    <Link
      to={to}
      className={`block px-3 py-2 rounded-md text-base font-medium ${
        current
          ? 'text-white bg-[#fc4b08]'
          : 'text-[#fc4b08] hover:text-white hover:bg-[#fc4b08] dark:text-[#fc4b08] dark:hover:text-white'
      }`}
      onClick={onClick}
    >
      {children}
    </Link>
  );
};

export default Navbar;