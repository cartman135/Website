import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Mail, MapPin, Clock, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and About */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center mb-4">
              <ShoppingBag size={32} className="text-[#fc4b08]" />
              <span className="ml-2 text-2xl font-bold text-[#fc4b08]">Pilla Pilla</span>
            </div>
            <p className="text-gray-300 mb-4">
              Tus snacks favoritos disponibles 24/7 en nuestras máquinas expendedoras.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                <Instagram size={20} />
              </a>
              <a href="https://facebook.com" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://twitter.com" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-[#fc4b08]">Enlaces</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                  Inicio
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                  Productos
                </Link>
              </li>
              <li>
                <Link to="/locations" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                  Ubicaciones
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-[#fc4b08] transition-colors">
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-[#fc4b08]">Contacto</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Mail className="mr-2 text-gray-300 flex-shrink-0 mt-1" size={18} />
                <span className="text-gray-300">info@pillapillasnacks.com</span>
              </li>
              <li className="flex items-start">
                <MapPin className="mr-2 text-gray-300 flex-shrink-0 mt-1" size={18} />
                <span className="text-gray-300">Calle Principal 123, Madrid, España</span>
              </li>
              <li className="flex items-start">
                <Clock className="mr-2 text-gray-300 flex-shrink-0 mt-1" size={18} />
                <span className="text-gray-300">Disponible 24/7</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4 text-[#fc4b08]">Boletín</h3>
            <p className="text-gray-300 mb-4">Suscríbete para recibir noticias sobre nuevos productos y ofertas.</p>
            <form className="space-y-2">
              <input
                type="email"
                placeholder="Tu email"
                className="w-full px-4 py-2 rounded bg-gray-800 border border-gray-700 text-gray-300 focus:outline-none focus:ring-2 focus:ring-[#fc4b08]"
                required
              />
              <button
                type="submit"
                className="w-full px-4 py-2 bg-[#fc4b08] text-white font-medium rounded hover:bg-[#e0430a] transition-colors duration-300"
              >
                Suscribirse
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>© {new Date().getFullYear()} Pilla Pilla Snacks. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;