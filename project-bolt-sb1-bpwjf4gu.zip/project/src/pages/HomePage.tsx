import React, { useEffect, useRef } from 'react';
import { ChevronRight, Clock, MapPin, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: <Clock className="w-12 h-12 text-[#fc4b08]" />,
      title: 'Disponible 24/7',
      description: 'Nuestras máquinas están disponibles a cualquier hora, todos los días del año.'
    },
    {
      icon: <MapPin className="w-12 h-12 text-[#fc4b08]" />,
      title: 'Ubicaciones Estratégicas',
      description: 'Encuentra nuestras máquinas en lugares convenientes de toda la ciudad.'
    },
    {
      icon: <ShieldCheck className="w-12 h-12 text-[#fc4b08]" />,
      title: 'Productos de Calidad',
      description: 'Seleccionamos cuidadosamente snacks y bebidas de la mejor calidad.'
    }
  ];

  const categories = [
    {
      name: 'Snacks Salados',
      image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      name: 'Dulces',
      image: 'https://images.pexels.com/photos/35629/bing-cherries-ripe-red-fruit.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      name: 'Bebidas',
      image: 'https://images.pexels.com/photos/2479242/pexels-photo-2479242.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      name: 'Saludables',
      image: 'https://images.pexels.com/photos/1132047/pexels-photo-1132047.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    }
  ];
  
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-[#fc4b08] min-h-[80vh] flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 text-shadow">
                <span className="block">Pilla Pilla</span>
                <span className="block text-white">Snacks</span>
              </h1>
              <p className="text-xl sm:text-2xl mb-8 text-white/90">
                Tus snacks favoritos disponibles 24/7 en nuestras máquinas expendedoras. ¡Pilla lo que quieras, cuando quieras!
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/products" className="btn-primary">
                  Ver Productos
                </Link>
                <Link to="/locations" className="btn-secondary">
                  Encontrar Máquinas
                </Link>
              </div>
            </div>
            <div className="relative">
              <img 
                src="/vending-machine.png" 
                alt="Máquina expendedora Pilla Pilla"
                className="w-full max-w-md mx-auto animate-float"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-[#fc4b08] mb-4">
              ¿Por qué elegir Pilla Pilla?
            </h2>
            <p className="text-black dark:text-gray-300 text-lg max-w-3xl mx-auto">
              Nuestras máquinas expendedoras están diseñadas pensando en ti, ofreciéndote la mejor experiencia.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="card hover-scale"
              >
                <div className="flex justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-[#fc4b08] mb-2">{feature.title}</h3>
                <p className="text-black dark:text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-[#fc4b08]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">
              Nuestras Categorías
            </h2>
            <p className="text-white/90 text-lg max-w-3xl mx-auto">
              Explora nuestra amplia selección de productos para todos los gustos.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Link 
                key={index}
                to="/products" 
                className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-shadow hover-scale"
              >
                <div className="aspect-w-1 aspect-h-1 w-full">
                  <img 
                    src={category.image} 
                    alt={category.name} 
                    className="w-full h-64 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex items-end">
                    <h3 className="text-xl font-semibold text-white p-6 w-full text-shadow">
                      {category.name}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link 
              to="/products" 
              className="btn-primary inline-flex items-center"
            >
              Ver todos los productos
              <ChevronRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-[#fc4b08] mb-6">
            ¿Buscas instalar una máquina en tu negocio?
          </h2>
          <p className="text-black dark:text-gray-300 text-xl mb-8 max-w-3xl mx-auto">
            Ofrecemos soluciones personalizadas para empresas, oficinas, hospitales, universidades y más.
          </p>
          <Link 
            to="/contact" 
            className="btn-secondary"
          >
            Contáctanos
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;