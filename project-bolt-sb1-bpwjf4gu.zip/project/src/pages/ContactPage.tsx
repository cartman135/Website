import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageCircle } from 'lucide-react';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    type: 'contact' // Default is 'contact', can also be 'suggestion'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleTypeChange = (type: 'contact' | 'suggestion') => {
    setFormData(prev => ({ ...prev, type }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would send the data to a server
    console.log('Form submitted:', formData);
    alert('¡Gracias por tu mensaje! Te responderemos lo antes posible.');
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
      type: 'contact'
    });
  };

  return (
    <div className="pt-16 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-[#fc4b08] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-6">Contáctanos</h1>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Estamos aquí para ayudarte. Envíanos un mensaje y responderemos lo antes posible.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="md:flex">
            {/* Contact Info */}
            <div className="md:w-1/3 bg-gray-900 p-8 text-white">
              <h2 className="text-2xl font-bold mb-6 text-[#fc4b08]">Información de Contacto</h2>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <Mail className="text-[#fc4b08] mt-1 flex-shrink-0" size={20} />
                  <div className="ml-4">
                    <h3 className="font-semibold mb-1">Email</h3>
                    <p className="text-gray-300">info@pillapillasnacks.com</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Phone className="text-[#fc4b08] mt-1 flex-shrink-0" size={20} />
                  <div className="ml-4">
                    <h3 className="font-semibold mb-1">Teléfono</h3>
                    <p className="text-gray-300">+34 912 345 678</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <MapPin className="text-[#fc4b08] mt-1 flex-shrink-0" size={20} />
                  <div className="ml-4">
                    <h3 className="font-semibold mb-1">Dirección</h3>
                    <p className="text-gray-300">Calle Principal 123<br />28001 Madrid, España</p>
                  </div>
                </div>
              </div>

              <div className="mt-12">
                <h3 className="font-semibold mb-3">Horario de Atención</h3>
                <p className="text-gray-300">Lunes a Viernes: 9:00 - 18:00</p>
                <p className="text-gray-300">Nuestras máquinas: 24/7</p>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="md:w-2/3 p-8">
              <div className="mb-6">
                <div className="inline-flex rounded-md shadow-sm" role="group">
                  <button
                    type="button"
                    onClick={() => handleTypeChange('contact')}
                    className={`flex items-center px-4 py-2 text-sm font-medium rounded-l-lg ${
                      formData.type === 'contact'
                        ? 'bg-[#fc4b08] text-white'
                        : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <Mail className="mr-2" size={16} />
                    Contacto
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTypeChange('suggestion')}
                    className={`flex items-center px-4 py-2 text-sm font-medium rounded-r-lg ${
                      formData.type === 'suggestion'
                        ? 'bg-[#fc4b08] text-white'
                        : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <MessageCircle className="mr-2" size={16} />
                    Sugerencia
                  </button>
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-6">
                {formData.type === 'contact' ? 'Envíanos un mensaje' : 'Envíanos tu sugerencia'}
              </h2>
              
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Nombre
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#fc4b08] focus:border-[#fc4b08]"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#fc4b08] focus:border-[#fc4b08]"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Asunto
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#fc4b08] focus:border-[#fc4b08]"
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    {formData.type === 'contact' ? 'Mensaje' : 'Tu sugerencia'}
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[#fc4b08] focus:border-[#fc4b08]"
                    placeholder={formData.type === 'suggestion' ? 'Comparte tu idea para mejorar nuestro servicio...' : 'Escribe tu mensaje aquí...'}
                  ></textarea>
                </div>
                
                <button
                  type="submit"
                  className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#fc4b08] hover:bg-[#e0430a] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#fc4b08] transition-colors"
                >
                  <Send className="mr-2" size={18} />
                  {formData.type === 'contact' ? 'Enviar Mensaje' : 'Enviar Sugerencia'}
                </button>
              </form>
            </div>
          </div>
        </div>
        
        {/* FAQ Section */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Preguntas Frecuentes</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Cómo puedo reportar una máquina que no funciona?</h3>
              <p className="text-gray-700">
                Puedes reportar cualquier incidencia a través de nuestro formulario de contacto, por teléfono o enviándonos un email. Asegúrate de incluir la ubicación exacta de la máquina.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Qué métodos de pago aceptan las máquinas?</h3>
              <p className="text-gray-700">
                Nuestras máquinas aceptan efectivo, tarjetas de crédito/débito y pagos móviles. Algunas ubicaciones pueden tener opciones adicionales.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Cómo puedo solicitar una máquina para mi negocio?</h3>
              <p className="text-gray-700">
                Puedes contactarnos a través del formulario en esta página o llamarnos directamente. Evaluaremos tu ubicación y te proporcionaremos todas las opciones disponibles.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Ofrecen opciones para personas con alergias o restricciones alimentarias?</h3>
              <p className="text-gray-700">
                Sí, muchas de nuestras máquinas incluyen opciones sin gluten, vegetarianas y veganas. La disponibilidad puede variar según la ubicación.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;