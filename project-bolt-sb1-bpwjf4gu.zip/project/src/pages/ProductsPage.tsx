import React, { useState } from 'react';
import { Search } from 'lucide-react';

const ProductsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Categories
  const categories = [
    { id: 'all', name: 'Todos' },
    { id: 'salty', name: 'Snacks Salados' },
    { id: 'sweet', name: 'Dulces' },
    { id: 'drinks', name: 'Bebidas' },
    { id: 'healthy', name: 'Saludables' }
  ];

  // Product data
  const products = [
    {
      id: 1,
      name: 'Patatas Fritas Clásicas',
      price: 1.50,
      category: 'salty',
      image: 'https://images.pexels.com/photos/5926649/pexels-photo-5926649.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: true
    },
    {
      id: 2,
      name: 'Chocolatina Deluxe',
      price: 1.25,
      category: 'sweet',
      image: 'https://images.pexels.com/photos/65882/chocolate-dark-coffee-confiserie-65882.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: true
    },
    {
      id: 3,
      name: 'Refresco de Cola',
      price: 2.00,
      category: 'drinks',
      image: 'https://images.pexels.com/photos/2983100/pexels-photo-2983100.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: false
    },
    {
      id: 4,
      name: 'Barrita de Cereales',
      price: 1.75,
      category: 'healthy',
      image: 'https://images.pexels.com/photos/1028599/pexels-photo-1028599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: false
    },
    {
      id: 5,
      name: 'Galletas de Chocolate',
      price: 1.50,
      category: 'sweet',
      image: 'https://images.pexels.com/photos/890577/pexels-photo-890577.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: true
    },
    {
      id: 6,
      name: 'Agua Mineral',
      price: 1.25,
      category: 'drinks',
      image: 'https://images.pexels.com/photos/327090/pexels-photo-327090.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: false
    },
    {
      id: 7,
      name: 'Mix de Frutos Secos',
      price: 2.25,
      category: 'healthy',
      image: 'https://images.pexels.com/photos/1295572/pexels-photo-1295572.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: true
    },
    {
      id: 8,
      name: 'Nachos con Queso',
      price: 2.50,
      category: 'salty',
      image: 'https://images.pexels.com/photos/1108775/pexels-photo-1108775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      popular: false
    }
  ];

  // Filter products based on category and search query
  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pt-16 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-[#fc4b08] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-6">Nuestros Productos</h1>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Descubre todos los deliciosos productos disponibles en nuestras máquinas expendedoras.
          </p>
          
          {/* Search bar */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar productos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full py-3 pl-10 pr-4 bg-white rounded-full shadow-md focus:outline-none focus:ring-2 focus:ring-white/50"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Categories */}
        <div className="mb-8 flex flex-wrap justify-center gap-2">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category.id
                  ? 'bg-[#fc4b08] text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } shadow-sm`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Products */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <div 
              key={product.id} 
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative h-48">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover"
                />
                {product.popular && (
                  <span className="absolute top-2 right-2 bg-[#fc4b08] text-white text-xs font-bold px-2 py-1 rounded-full">
                    Popular
                  </span>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-1">{product.name}</h3>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-[#fc4b08] font-bold">{product.price.toFixed(2)} €</span>
                  <span className="text-xs text-white bg-gray-700 px-2 py-1 rounded-full">
                    {categories.find(c => c.id === product.category)?.name}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* No results */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No se encontraron productos que coincidan con tu búsqueda.</p>
            <button 
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="mt-4 text-[#fc4b08] font-medium hover:underline"
            >
              Ver todos los productos
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductsPage;