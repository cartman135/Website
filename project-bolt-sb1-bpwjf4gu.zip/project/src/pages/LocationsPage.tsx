import React, { useState } from 'react';
import { MapPin, Search, ChevronDown, Clock, CreditCard, Route } from 'lucide-react';

const LocationsPage: React.FC = () => {
  const [selectedZone, setSelectedZone] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Zones
  const zones = [
    { id: 'all', name: 'Todas las zonas' },
    { id: 'centro', name: 'Centro' },
    { id: 'norte', name: 'Norte' },
    { id: 'sur', name: 'Sur' },
    { id: 'este', name: 'Este' },
    { id: 'oeste', name: 'Oeste' }
  ];

  // Locations data
  const locations = [
    {
      id: 1,
      name: 'Estación Central',
      address: 'Calle Mayor 123, Madrid',
      zone: 'centro',
      image: 'https://images.pexels.com/photos/2246790/pexels-photo-2246790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      features: ['24h', 'Tarjeta de crédito', 'Múltiples máquinas'],
      popular: true
    },
    {
      id: 2,
      name: 'Centro Comercial Norte',
      address: 'Avenida Principal 45, Madrid',
      zone: 'norte',
      image: 'https://images.pexels.com/photos/3184639/pexels-photo-3184639.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      features: ['24h', 'Tarjeta de crédito'],
      popular: true
    },
    {
      id: 3,
      name: 'Hospital General',
      address: 'Plaza de la Salud 7, Madrid',
      zone: 'este',
      image: 'https://images.pexels.com/photos/247786/pexels-photo-247786.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      features: ['24h', 'Tarjeta de crédito', 'Productos saludables'],
      popular: false
    },
    {
      id: 4,
      name: 'Universidad Central',
      address: 'Avenida Universitaria 28, Madrid',
      zone: 'oeste',
      image: 'https://images.pexels.com/photos/207692/pexels-photo-207692.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      features: ['Tarjeta de crédito', 'WiFi Gratuito'],
      popular: false
    },
    {
      id: 5,
      name: 'Parque Empresarial',
      address: 'Calle Industria 102, Madrid',
      zone: 'norte',
      image: 'https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      features: ['Tarjeta de crédito', 'Múltiples máquinas'],
      popular: true
    },
    {
      id: 6,
      name: 'Centro Deportivo Sur',
      address: 'Avenida del Deporte 33, Madrid',
      zone: 'sur',
      image: 'https://images.pexels.com/photos/260352/pexels-photo-260352.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      features: ['Productos saludables', 'Tarjeta de crédito'],
      popular: false
    }
  ];

  // Filter locations based on zone and search query
  const filteredLocations = locations.filter(location => {
    const matchesZone = selectedZone === 'all' || location.zone === selectedZone;
    const matchesSearch = 
      location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      location.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesZone && matchesSearch;
  });

  // Feature icons mapping
  const featureIcons = {
    '24h': <Clock size={16} />,
    'Tarjeta de crédito': <CreditCard size={16} />,
    'Múltiples máquinas': <MapPin size={16} />,
    'Productos saludables': <ChevronDown size={16} />,
    'WiFi Gratuito': <Route size={16} />
  };

  return (
    <div className="pt-16 bg-gray-50 min-h-screen">
      {/* Header with Map */}
      <div className="bg-[#fc4b08] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-6">Encuentra Nuestras Máquinas</h1>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Localiza la máquina expendedora más cercana y disfruta de tus snacks favoritos en cualquier momento.
          </p>
          
          {/* Search bar */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por ubicación o dirección..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full py-3 pl-10 pr-4 bg-white rounded-full shadow-md focus:outline-none focus:ring-2 focus:ring-white/50"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Zones filter */}
        <div className="mb-8 flex flex-wrap justify-center gap-2">
          {zones.map(zone => (
            <button
              key={zone.id}
              onClick={() => setSelectedZone(zone.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedZone === zone.id
                  ? 'bg-[#fc4b08] text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } shadow-sm`}
            >
              {zone.name}
            </button>
          ))}
        </div>

        {/* Locations */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredLocations.map(location => (
            <div 
              key={location.id} 
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative h-48">
                <img 
                  src={location.image} 
                  alt={location.name} 
                  className="w-full h-full object-cover"
                />
                {location.popular && (
                  <span className="absolute top-2 right-2 bg-[#fc4b08] text-white text-xs font-bold px-2 py-1 rounded-full">
                    Popular
                  </span>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 text-lg mb-1">{location.name}</h3>
                <div className="flex items-start mb-3">
                  <MapPin className="text-[#fc4b08] mt-1 flex-shrink-0" size={18} />
                  <p className="ml-2 text-gray-600">{location.address}</p>
                </div>
                
                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {location.features.map((feature, index) => (
                    <span 
                      key={index}
                      className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                    >
                      {featureIcons[feature as keyof typeof featureIcons]}
                      {feature}
                    </span>
                  ))}
                </div>
                
                <a 
                  href={`https://maps.google.com/?q=${encodeURIComponent(location.address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block w-full text-center py-2 bg-[#fc4b08] text-white font-medium rounded-lg hover:bg-[#e0430a] transition-colors"
                >
                  Ver en Mapa
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* No results */}
        {filteredLocations.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No se encontraron ubicaciones que coincidan con tu búsqueda.</p>
            <button 
              onClick={() => {
                setSelectedZone('all');
                setSearchQuery('');
              }}
              className="mt-4 text-[#fc4b08] font-medium hover:underline"
            >
              Ver todas las ubicaciones
            </button>
          </div>
        )}

        {/* CTA for location suggestion */}
        <div className="mt-16 bg-white p-8 rounded-lg shadow-md text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">¿Quieres una máquina en tu zona?</h3>
          <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
            Si deseas tener una máquina expendedora Pilla Pilla en tu barrio, negocio o institución, ¡cuéntanos! Evaluamos constantemente nuevas ubicaciones.
          </p>
          <a 
            href="/contact"
            className="inline-block px-6 py-3 bg-[#fc4b08] text-white font-medium rounded-lg hover:bg-[#e0430a] transition-colors"
          >
            Sugerir Nueva Ubicación
          </a>
        </div>
      </div>
    </div>
  );
};

export default LocationsPage;